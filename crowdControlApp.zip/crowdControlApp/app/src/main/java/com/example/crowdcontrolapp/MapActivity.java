package com.example.crowdcontrolapp;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MapActivity extends AppCompatActivity {

    private View sectionA, sectionB, sectionC, sectionD;
    private static final int THRESHOLD = 5;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Event Map");
        }

        sectionA = findViewById(R.id.sectionA);
        sectionB = findViewById(R.id.sectionB);
        sectionC = findViewById(R.id.sectionC);
        sectionD = findViewById(R.id.sectionD);

        updateSectionColors();
    }

    private void updateSectionColors() {
        SharedPreferences prefs = getSharedPreferences("CrowdData", MODE_PRIVATE);

        int countA = prefs.getInt("SectionA", 0);
        int countB = prefs.getInt("SectionB", 0);
        int countC = prefs.getInt("SectionC", 0);
        int countD = prefs.getInt("SectionD", 0);

        if (countA > THRESHOLD) {
            sectionA.setBackgroundColor(Color.RED);
        } else {
            sectionA.setBackgroundColor(Color.LTGRAY);
        }

        if (countB > THRESHOLD) {
            sectionB.setBackgroundColor(Color.RED);
        } else {
            sectionB.setBackgroundColor(Color.LTGRAY);
        }

        if (countC > THRESHOLD) {
            sectionC.setBackgroundColor(Color.RED);
        } else {
            sectionC.setBackgroundColor(Color.LTGRAY);
        }

        if (countD > THRESHOLD) {
            sectionD.setBackgroundColor(Color.RED);
        } else {
            sectionD.setBackgroundColor(Color.LTGRAY);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}