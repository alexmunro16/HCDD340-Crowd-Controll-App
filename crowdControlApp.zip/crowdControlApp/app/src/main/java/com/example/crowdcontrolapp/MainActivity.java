package com.example.crowdcontrolapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button attendeeButton, staffButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        attendeeButton = findViewById(R.id.attendeeButton);
        staffButton = findViewById(R.id.staffButton);

        attendeeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent attendeeIntent = new Intent(MainActivity.this, AttendeeHomeActivity.class);
                startActivity(attendeeIntent);
            }
        });

        staffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent staffIntent = new Intent(MainActivity.this, StaffDashboardActivity.class);
                startActivity(staffIntent);
            }
        });
    }
}
