package com.example.crowdcontrolapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;

public class StaffDashboardActivity extends AppCompatActivity {

    private int crowdCount = 0;
    private TextView crowdCountLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_dashboard);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Staff Dashboard");
        }

        crowdCountLabel = findViewById(R.id.crowdCountLabel);
        Button incrementBtn = findViewById(R.id.incrementBtn);
        Button decrementBtn = findViewById(R.id.decrementBtn);

        incrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateCrowdCount(1, v);
            }
        });

        decrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateCrowdCount(-1, v);
            }
        });
    }

    private void updateCrowdCount(int change, View view) {
        crowdCount += change;
        crowdCountLabel.setText("Current Count: " + crowdCount);

        if (crowdCount > 50) {
            Snackbar.make(view, "Warning: Area is over capacity!", Snackbar.LENGTH_LONG).show();
        } else if (crowdCount < 0) {
            Snackbar.make(view, "Warning: Count cannot be negative!", Snackbar.LENGTH_SHORT).show();
            crowdCount = 0; // reset to 0 if negative
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}