package com.example.crowdcontrolapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;

public class StaffDashboardActivity extends AppCompatActivity {

    private int crowdCount = 0;
    private TextView crowdCountLabel;
    private Button incrementBtn;
    private Button decrementBtn;
    private Button resetBtn;

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    private String selectedSection = "SectionB";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_dashboard);

        prefs = getSharedPreferences("CrowdData", MODE_PRIVATE);
        editor = prefs.edit();

        selectedSection = getIntent().getStringExtra("selected_section");
        if (selectedSection == null) {
            selectedSection = "SectionB";
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Staff Dashboard");
        }

        crowdCountLabel = findViewById(R.id.crowdCountLabel);
        incrementBtn = findViewById(R.id.incrementBtn);
        decrementBtn = findViewById(R.id.decrementBtn);
        resetBtn = findViewById(R.id.resetBtn);

        incrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateCrowdCount(1, v);
            }
        });

        decrementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateCrowdCount(-1, v);
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crowdCount = 0;
                crowdCountLabel.setText("Current Count: 0");
                saveCrowdCount();
                Snackbar.make(v, "Count has been reset.", Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    private void updateCrowdCount(int change, View view) {
        crowdCount += change;

        if (crowdCount > 5) {
            Snackbar.make(view, "Warning: Area is over capacity!", Snackbar.LENGTH_LONG).show();
        } else if (crowdCount < 0) {
            Snackbar.make(view, "Warning: Count cannot be negative!", Snackbar.LENGTH_SHORT).show();
            crowdCount = 0;
        }

        crowdCountLabel.setText("Current Count: " + crowdCount);
        saveCrowdCount();
    }

    private void saveCrowdCount() {
        if (selectedSection != null) {
            String cleanKey = selectedSection.replace(" ", "");
            editor.putInt(cleanKey, crowdCount);
            editor.apply();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
