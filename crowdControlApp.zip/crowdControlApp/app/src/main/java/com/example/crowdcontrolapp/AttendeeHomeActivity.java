package com.example.crowdcontrolapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AttendeeHomeActivity extends AppCompatActivity {

    private TextView alertText;
    private TextView alertSectionAText, alertSectionBText, alertSectionCText, alertSectionDText;
    private Button openMapBtn;

    private static final int THRESHOLD = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendee_home);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Attendee View");
        }

        alertText = findViewById(R.id.alertText);
        alertSectionAText = findViewById(R.id.alertSectionAText);
        alertSectionBText = findViewById(R.id.alertSectionBText);
        alertSectionCText = findViewById(R.id.alertSectionCText);
        alertSectionDText = findViewById(R.id.alertSectionDText);
        openMapBtn = findViewById(R.id.openMapBtn);

        updateSectionAlerts();

        openMapBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AttendeeHomeActivity.this, MapActivity.class);
                startActivity(intent);
            }
        });
    }

    private void updateSectionAlerts() {
        SharedPreferences prefs = getSharedPreferences("CrowdData", MODE_PRIVATE);

        int sectionACount = prefs.getInt("SectionA", 0);
        int sectionBCount = prefs.getInt("SectionB", 0);
        int sectionCCount = prefs.getInt("SectionC", 0);
        int sectionDCount = prefs.getInt("SectionD", 0);

        if (sectionACount > THRESHOLD) {
            alertSectionAText.setText("Section A is at capacity!");
            alertSectionAText.setVisibility(View.VISIBLE);
        } else {
            alertSectionAText.setVisibility(View.GONE);
        }

        if (sectionBCount > THRESHOLD) {
            alertSectionBText.setText("Section B is at capacity!");
            alertSectionBText.setVisibility(View.VISIBLE);
        } else {
            alertSectionBText.setVisibility(View.GONE);
        }

        if (sectionCCount > THRESHOLD) {
            alertSectionCText.setText("Section C is at capacity!");
            alertSectionCText.setVisibility(View.VISIBLE);
        } else {
            alertSectionCText.setVisibility(View.GONE);
        }

        if (sectionDCount > THRESHOLD) {
            alertSectionDText.setText("Section D is at capacity!");
            alertSectionDText.setVisibility(View.VISIBLE);
        } else {
            alertSectionDText.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
